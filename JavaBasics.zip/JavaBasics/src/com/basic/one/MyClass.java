package com.basic.one;
public class MyClass {

    public static void main(String[] args) {
        System.out.println( args[0] );
        System.out.println( args[1] );
    }
}