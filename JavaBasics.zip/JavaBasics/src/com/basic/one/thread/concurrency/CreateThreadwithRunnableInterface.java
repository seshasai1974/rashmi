package com.basic.one.thread.concurrency;
class CreateThreadwithRunnableInterface implements Runnable{  
public void run(){  
System.out.println("thread create with runnable interface is running...");  
}  
  
public static void main(String args[]){  
CreateThreadwithRunnableInterface m1=new CreateThreadwithRunnableInterface();  
Thread t1 =new Thread(m1);  
t1.start();  
 }  
}  