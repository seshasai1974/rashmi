package com.basic.one.thread.concurrency;

public class ThreaadExample2 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}
//code to interface and not to class : Java does not support multiple inheritence 
	//Diamond Problem ; cyclic dependency
}

//  SOLID acronym principles
//  Single Responsibility , OpenClosed 

