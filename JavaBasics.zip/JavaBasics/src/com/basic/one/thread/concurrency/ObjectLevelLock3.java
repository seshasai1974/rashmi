package com.basic.one.thread.concurrency;
public class ObjectLevelLock3
{
    private final Object lock = new Object();
    
    
    public void demoMethod(){
        synchronized (lock)
        {
            //other thread safe code
        }
    }
 
}