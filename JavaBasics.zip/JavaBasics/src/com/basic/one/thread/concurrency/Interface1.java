package com.basic.one.thread.concurrency;

public interface Interface1 {
	
	public void myMethod();

}
