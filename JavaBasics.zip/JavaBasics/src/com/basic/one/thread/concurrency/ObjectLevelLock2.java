package com.basic.one.thread.concurrency;

public class ObjectLevelLock2 {
    public void demoMethod(){
        synchronized (this)
        {
            //other thread safe code
        	//update the file
        }
        
        {
        	// read the file
        }
    }
}
