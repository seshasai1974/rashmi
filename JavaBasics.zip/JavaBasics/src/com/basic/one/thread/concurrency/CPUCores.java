package com.basic.one.thread.concurrency;
public class CPUCores {
	//A system may contain multiple physical CPUs (central processing unit), 
	//cand can contain one or more cores (processors). Also, each core can have multiple threads, 
	//usually 2. (Hyper-threading Technology from Intel CPUs).
	
    public static void main(String[] args) {
      int processors = Runtime.getRuntime().availableProcessors();
      System.out.println("CPU cores: " + processors);
    }
}