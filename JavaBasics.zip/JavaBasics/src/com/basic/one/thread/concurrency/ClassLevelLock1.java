package com.basic.one.thread.concurrency;

public class ClassLevelLock1 {

	//Method is static
    public synchronized static void demoMethod() {
    	
    }
}
