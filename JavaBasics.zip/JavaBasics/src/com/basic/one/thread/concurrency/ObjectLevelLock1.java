package com.basic.one.thread.concurrency;

public class ObjectLevelLock1 {
	public synchronized void demoMethod(){
		
		/*
		 * some code 
		 */
		
	}

}
