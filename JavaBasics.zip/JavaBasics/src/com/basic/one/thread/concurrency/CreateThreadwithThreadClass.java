package com.basic.one.thread.concurrency;
class CreateThreadwithThreadClass extends Thread{  
public void run(){  
System.out.println("thread created by extending thread is running...");  
}  
public static void main(String args[]){  
CreateThreadwithThreadClass t1=new CreateThreadwithThreadClass();  
t1.start();  
 }  
}  