package com.basic.recursions.examples;

public class FibbonaciSeries {

	public static void main(String[] args) {
		
		int n = 10; 
		int first = 0;
		int sec = 1;
		int sum = 0;
		
		for(int i=0;i<=n;++i) {
			
			System.out.println(first + " + ");
			
			sum = first + sec;
			first = sec;
			sec = sum;
			
		}
		
		System.out.println(" SUM : " + sum);

	}

}
