package com.basic.recursions.examples;
public class RecursionExample1 {  
	static void p(){  
		System.out.println("hello");  
		for(int i=0 ; i<=5;i++)
		{	
			p();
			if(i==5) {
				break;
			}
				
		}
	}  
	  
	public static void main(String[] args) {  
		p();  
	}  
}  