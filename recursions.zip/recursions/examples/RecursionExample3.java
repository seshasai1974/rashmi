package com.basic.recursions.examples;
public class RecursionExample3 {  
	
	//direct recursion
    static int factorial(int n){      
          if (n == 1) 
          {
        	  System.out.println(" n(1) : " +n);
            return 1;      
          }
          else      
          {
        	  System.out.println("n : " + n);
            return(n * factorial(n-1));
            
          }
          
          
    }   
    //indirect recursion
    public static void method1() {
    	
    	method2();
    	
    }
    
    public static void method2() {
    	method1();
    }
  
public static void main(String[] args) {  
	System.out.println("Factorial of 5 is: "+factorial(5));  
}  
}  