package com.basic.one.optionalexamples.fileio;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;

public class ReadFileUsingFiles {

	public static void main(String[] args)  {
/*		try {
			List<String> allLines = Files.readAllLines(Paths.get("myfile.txt"));
			for (String line : allLines) {
				System.out.println(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		try {
			List<String> allLines = Files.readAllLines(Paths.get("myfile.txt"));
		}		
		catch(FileNotFoundException fnfe) {
			fnfe.printStackTrace();
			//if file not present it will come this catch
			System.out.println("fnfe");
		}		
		catch (IOException io) {
			// TODO Auto-generated catch block
			io.printStackTrace();
			//reading file it will come in this catch
			System.out.println("io");
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("e");
		}
		int z = 0;
		int y = 0;
		int a = z/y;
		System.out.println(" a : " + a);

}
	

}