package com.basic.one.optionalexamples.fileio;

import java.io.File;

public class FileHandling {
	
	public void readFile() {
		
		File file = new File("");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
