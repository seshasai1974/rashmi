package com.basic.one.optionalexamples.fileio;

public class MyException extends Exception {

}
