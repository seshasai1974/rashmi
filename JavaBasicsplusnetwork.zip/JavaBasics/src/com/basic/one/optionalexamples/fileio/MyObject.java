package com.basic.one.optionalexamples.fileio;

import java.io.Serializable;

public class MyObject implements Serializable {

}
