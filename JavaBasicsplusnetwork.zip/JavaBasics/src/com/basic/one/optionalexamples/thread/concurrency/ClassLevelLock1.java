package com.basic.one.optionalexamples.thread.concurrency;

public class ClassLevelLock1 {

	//Method is static
    public synchronized static void demoMethod() {
    	
    }
}
