package com.basic.one.optionalexamples.thread.concurrency;

public class ObjectLevelLock1 {
	public synchronized void demoMethod(){
		
		/*
		 * some code 
		 */
		
	}

}
