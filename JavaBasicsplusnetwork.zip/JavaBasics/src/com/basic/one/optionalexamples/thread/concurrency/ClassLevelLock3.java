package com.basic.one.optionalexamples.thread.concurrency;

public class ClassLevelLock3 {

	private final static Object lock = new Object();
	 
    public void demoMethod()
    {
        //Lock object is static
        synchronized (lock)
        {
            //other thread safe code
        }
    }
}
