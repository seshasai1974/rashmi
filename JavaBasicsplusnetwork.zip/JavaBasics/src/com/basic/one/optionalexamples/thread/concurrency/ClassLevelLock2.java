package com.basic.one.optionalexamples.thread.concurrency;

public class ClassLevelLock2 {

	 public void demoMethod()
	    {
	        //Acquire lock on .class reference
	        synchronized (ClassLevelLock2.class)
	        {
	            //other thread safe code
	        }
	    }
}
