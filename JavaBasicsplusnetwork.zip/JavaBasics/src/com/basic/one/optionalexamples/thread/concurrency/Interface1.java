package com.basic.one.optionalexamples.thread.concurrency;

public interface Interface1 {
	
	public void myMethod();

}
